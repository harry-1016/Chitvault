import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// Register service worker for PWA
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((reg) => {
        console.log('[ChitVault] SW registered:', reg.scope);

        // Check for updates every 60 seconds
        setInterval(() => reg.update(), 60000);
      })
      .catch((err) => {
        console.log('[ChitVault] SW registration failed:', err);
      });
  });
}
