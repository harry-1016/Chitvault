# ChitVault 💰

**Professional Chit Fund Management System — PWA**

A full-featured Progressive Web App for managing chit funds with real-time Firebase sync, WhatsApp notifications, and installable offline support.

---

## ✨ Features

- 🔐 **Firebase Authentication** — Username/password login with role-based access (Owner, Manager, Collector, Viewer)
- 📊 **Dashboard** — Real-time stats: collections, defaulters, active groups
- ◈ **Chit Groups** — Create and track chit schemes with progress bars
- ◉ **Members** — Full member profiles with Aadhaar, PAN, nominee details
- ◎ **Collections** — Record payments with auto receipt generation
- 📄 **Receipts** — View, print, and share payment receipts
- 💬 **WhatsApp Reminders** — Send due reminders, overdue alerts, and auction notices via wa.me
- 📈 **Reports** — Group-wise collection analytics
- 👥 **User Manager** — Owner-only staff account creation
- 📲 **PWA Install** — Add to home screen, works on mobile & desktop
- 🔌 **Offline Banner** — Visual indicator when Firebase sync is paused

---

## 🚀 Deploy to GitHub Pages

### One-time setup

1. **Fork or clone this repo**
2. Go to **Settings → Pages**
3. Set **Source** to `gh-pages` branch (auto-created by CI)
4. Push to `main` — GitHub Actions builds and deploys automatically

### Manual deploy

```bash
npm install
npm run build
npm run deploy    # pushes build/ to gh-pages branch
```

---

## 🛠 Local Development

```bash
npm install
npm start         # http://localhost:3000
```

---

## 🔥 Firebase Setup

The app uses Firebase REST API — no SDK install needed. The config in `src/App.jsx` is pre-configured. To use your own Firebase project:

1. Create a project at [console.firebase.google.com](https://console.firebase.google.com)
2. Enable **Authentication → Email/Password**
3. Create **Firestore Database** with these collections:
   - `groups`, `members`, `collections`, `app_users`
4. Set Firestore rules to authenticated users only:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

5. Replace `FB_CONFIG` in `src/App.jsx` with your project's config

---

## 👑 Default Login

| Username | Password | Role |
|----------|----------|------|
| harikrishna | 123456789 | Owner (full access) |

Create additional users via **User Manager** tab (owner only).

---

## 📁 Project Structure

```
chitvault-pwa/
├── public/
│   ├── index.html          # HTML shell with PWA meta tags
│   ├── manifest.json       # PWA manifest (name, icons, theme)
│   ├── sw.js               # Service worker (caching + offline)
│   ├── logo192.png         # App icon 192×192
│   └── logo512.png         # App icon 512×512
├── src/
│   ├── App.jsx             # Main application (all components)
│   ├── usePWA.js           # PWA hooks (install prompt, online status)
│   ├── index.js            # React entry + SW registration
│   └── index.css           # Global reset styles
├── .github/
│   └── workflows/
│       └── deploy.yml      # Auto-deploy to GitHub Pages on push
├── package.json
└── README.md
```

---

## 📱 PWA Install

On Chrome/Edge: click the **Install** button in the address bar or the in-app install banner.  
On iOS Safari: tap **Share → Add to Home Screen**.

---

Built with React 18 · Firebase REST API · GitHub Actions
